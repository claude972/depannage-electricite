import React from 'react';

export default function Tracking() {
  const steps = [
    { label: 'Demande créée', done: true },
    { label: 'Artisan assigné', done: true },
    { label: 'En route', done: true },
    { label: 'Sur place', done: false },
    { label: 'Terminé', done: false },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto bg-white rounded-2xl shadow p-6">
        <h2 className="text-xl font-bold mb-6">Suivi de l’intervention</h2>
        
        <div className="space-y-4">
          {steps.map((step, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${step.done ? 'bg-green-500' : 'bg-gray-300'}`}>
                {step.done ? '✓' : i + 1}
              </div>
              <span className={step.done ? 'font-medium' : 'text-gray-500'}>{step.label}</span>
            </div>
          ))}
        </div>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <p className="font-semibold">Julien Moreau</p>
          <p className="text-sm text-gray-600">Arrive dans ~15 min</p>
          <button className="mt-2 text-blue-600 font-medium">Contacter</button>
        </div>
      </div>
    </div>
  );
}
