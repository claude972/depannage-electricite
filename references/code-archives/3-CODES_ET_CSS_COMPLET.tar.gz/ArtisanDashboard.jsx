import React from 'react';

export default function ArtisanDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-2xl shadow p-5 mb-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="font-bold text-lg">Bonjour Thomas</h2>
              <p className="text-sm text-gray-600">Artisan électricien</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm">Disponible</span>
              <div className="w-12 h-6 bg-green-500 rounded-full"></div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow p-5 mb-4">
          <h3 className="font-semibold mb-3">Missions à venir</h3>
          <div className="space-y-3">
            <div className="border rounded-lg p-3">
              <p className="font-medium">Panne de courant</p>
              <p className="text-sm text-gray-600">Paris 15e • 14h30</p>
            </div>
            <div className="border rounded-lg p-3">
              <p className="font-medium">Remplacement prise</p>
              <p className="text-sm text-gray-600">Boulogne • 16h00</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow p-5">
          <p className="text-sm text-gray-600">Gains ce mois</p>
          <p className="text-3xl font-bold text-blue-600">1 842 €</p>
        </div>
      </div>
    </div>
  );
}
