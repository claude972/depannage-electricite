import React from 'react';

export default function ArtisanMission() {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto bg-white rounded-2xl shadow p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-xl font-bold">Nouvelle mission</h2>
            <p className="text-gray-600">Paris 15e</p>
          </div>
          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">Disponible</span>
        </div>

        <div className="space-y-3 mb-6">
          <p><strong>Type :</strong> Panne de courant</p>
          <p><strong>Fourchette :</strong> 180 – 280 €</p>
          <p className="text-sm text-gray-600">Client : Marie D.</p>
        </div>

        <div className="flex gap-3">
          <button className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold">Accepter</button>
          <button className="flex-1 border border-gray-300 py-3 rounded-lg">Refuser</button>
        </div>
      </div>
    </div>
  );
}
