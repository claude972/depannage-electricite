import React from 'react';

export default function B2BDashboard() {
  const sites = [
    { name: 'Restaurant Le Gourmet', interventions: 2, budget: '68%' },
    { name: 'Tour Horizon', interventions: 1, budget: '42%' },
    { name: 'Hôtel Le Régent', interventions: 3, budget: '81%' },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex">
        <aside className="w-64 bg-white border-r p-4 hidden md:block">
          <h2 className="font-bold text-lg mb-6">SyndicPro</h2>
          <nav className="space-y-2">
            <div className="bg-blue-50 text-blue-700 px-3 py-2 rounded">Tableau de bord</div>
            <div className="px-3 py-2 text-gray-600">Immeubles</div>
            <div className="px-3 py-2 text-gray-600">Interventions</div>
          </nav>
        </aside>

        <main className="flex-1 p-6">
          <h1 className="text-2xl font-bold mb-6">Tableau de bord</h1>
          <div className="grid gap-4">
            {sites.map((site, i) => (
              <div key={i} className="bg-white p-4 rounded-xl shadow-sm flex justify-between">
                <div>
                  <p className="font-semibold">{site.name}</p>
                  <p className="text-sm text-gray-600">{site.interventions} interventions en cours</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{site.budget}</p>
                  <p className="text-sm text-gray-500">Budget utilisé</p>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
