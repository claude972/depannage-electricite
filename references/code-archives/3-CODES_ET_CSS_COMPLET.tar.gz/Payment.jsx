import React from 'react';

export default function Payment() {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto bg-white rounded-2xl shadow p-6">
        <h2 className="text-xl font-bold mb-2">Paiement</h2>
        <p className="text-gray-600 mb-6">Intervention terminée</p>

        <div className="bg-gray-50 rounded-xl p-4 mb-6">
          <div className="flex justify-between mb-2">
            <span>Main d’œuvre</span>
            <span>180,00 €</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Pièces</span>
            <span>45,00 €</span>
          </div>
          <div className="border-t pt-2 flex justify-between font-bold text-lg">
            <span>Total TTC</span>
            <span className="text-blue-600">225,00 €</span>
          </div>
        </div>

        <button className="w-full bg-green-600 text-white py-4 rounded-xl font-semibold text-lg">
          Payer 225,00 €
        </button>
        <p className="text-center text-xs text-gray-500 mt-3">Paiement sécurisé</p>
      </div>
    </div>
  );
}
