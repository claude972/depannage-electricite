import React from 'react';

export default function SiteDetail() {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white border-b p-4">
        <h1 className="text-xl font-bold">Restaurant Le Gourmet</h1>
        <p className="text-sm text-gray-600">12 Rue des Bouchers, Paris</p>
      </div>

      <div className="p-4 space-y-4">
        <div className="bg-white rounded-xl p-4">
          <h3 className="font-semibold mb-2">Interventions en cours</h3>
          <div className="border-l-4 border-orange-500 pl-3 py-1">
            <p>Révision tableau cuisine</p>
            <p className="text-sm text-gray-600">En cours depuis 14/05</p>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4">
          <h3 className="font-semibold mb-2">Budget 2025</h3>
          <p className="text-2xl font-bold">7 350 € / 24 000 €</p>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div className="bg-blue-600 h-2 rounded-full" style={{width: '30%'}}></div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4">
          <h3 className="font-semibold mb-2">Contact sur site</h3>
          <p>Marc Lemoine</p>
          <p className="text-sm text-gray-600">06 12 34 56 78</p>
        </div>
      </div>
    </div>
  );
}
