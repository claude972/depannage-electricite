import React, { useState } from 'react';

export default function Rating() {
  const [stars, setStars] = useState(0);

  return (
    <div className="min-h-screen bg-gray-50 p-4 flex items-center">
      <div className="max-w-md mx-auto bg-white rounded-2xl shadow p-6 w-full text-center">
        <h2 className="text-2xl font-bold mb-2">Votre avis compte</h2>
        <p className="text-gray-600 mb-6">Comment s’est passée l’intervention ?</p>

        <div className="flex justify-center gap-2 mb-6">
          {[1,2,3,4,5].map((n) => (
            <button 
              key={n} 
              onClick={() => setStars(n)}
              className={`text-4xl ${n <= stars ? 'text-yellow-400' : 'text-gray-300'}`}
            >
              ★
            </button>
          ))}
        </div>

        <textarea 
          className="w-full border rounded-lg p-3 mb-4" 
          placeholder="Votre commentaire (facultatif)"
          rows={3}
        />

        <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold">
          Envoyer mon avis
        </button>
      </div>
    </div>
  );
}
