import React from 'react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">⚡</div>
          <span className="font-bold text-xl">Élec Pro</span>
        </div>
        <nav className="hidden md:flex gap-6">
          <a href="#" className="text-gray-600">Accueil</a>
          <a href="#" className="text-gray-600">Comment ça marche</a>
          <a href="#" className="text-gray-600">Tarifs</a>
        </nav>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Connexion</button>
      </header>

      {/* Hero */}
      <section className="px-6 py-16 text-center max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
          Un électricien en quelques minutes
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Intervention rapide, prix transparent, artisans qualifiés.
        </p>
        <button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-4 rounded-xl font-semibold">
          J’ai besoin d’un électricien
        </button>
      </section>

      {/* 3 étapes */}
      <section className="px-6 py-12 bg-gray-50">
        <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-4xl mb-3">1</div>
            <h3 className="font-semibold text-lg">Décrivez votre problème</h3>
            <p className="text-gray-600">En quelques clics</p>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-3">2</div>
            <h3 className="font-semibold text-lg">Un artisan vous est assigné</h3>
            <p className="text-gray-600">Rapidement</p>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-3">3</div>
            <h3 className="font-semibold text-lg">Intervention & paiement</h3>
            <p className="text-gray-600">Simple et sécurisé</p>
          </div>
        </div>
      </section>
    </div>
  );
}
