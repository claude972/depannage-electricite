# Codes des pages – Application Dépannage Électricité

Composants React/Next.js de base pour les pages principales.

## Fichiers
- `HomePage.jsx` : Page d’accueil
- `CreateRequest.jsx` : Création de demande (avec fourchette de prix)
- `Tracking.jsx` : Suivi d’intervention
- `ArtisanMission.jsx` : Nouvelle mission artisan
- `B2BDashboard.jsx` : Tableau de bord B2B / Syndic

## Utilisation
Ces composants sont des bases. Ils utilisent Tailwind CSS.
À adapter selon votre stack (Next.js, React Native, etc.).

Toutes les maquettes correspondantes sont dans les volumes PDF.
