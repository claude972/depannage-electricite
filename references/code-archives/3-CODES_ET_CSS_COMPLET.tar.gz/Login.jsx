import React, { useState } from 'react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-blue-600 rounded-full mx-auto flex items-center justify-center text-white text-2xl mb-3">⚡</div>
          <h1 className="text-2xl font-bold">Connexion</h1>
        </div>

        <form className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border rounded-lg px-4 py-3"
              placeholder="vous@email.fr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Mot de passe</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border rounded-lg px-4 py-3"
            />
          </div>
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold">
            Se connecter
          </button>
        </form>

        <p className="text-center mt-4 text-sm">
          <a href="#" className="text-blue-600">Mot de passe oublié ?</a>
        </p>
      </div>
    </div>
  );
}
