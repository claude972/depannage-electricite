import React, { useState } from 'react';

export default function Signup() {
  const [role, setRole] = useState('client');

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h1 className="text-2xl font-bold text-center mb-6">Créer un compte</h1>

        <div className="flex gap-2 mb-6">
          <button 
            onClick={() => setRole('client')}
            className={`flex-1 py-2 rounded-lg ${role === 'client' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
          >
            Client
          </button>
          <button 
            onClick={() => setRole('artisan')}
            className={`flex-1 py-2 rounded-lg ${role === 'artisan' ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}
          >
            Artisan
          </button>
        </div>

        <form className="space-y-4">
          <input className="w-full border rounded-lg px-4 py-3" placeholder="Nom complet" />
          <input type="email" className="w-full border rounded-lg px-4 py-3" placeholder="Email" />
          <input type="tel" className="w-full border rounded-lg px-4 py-3" placeholder="Téléphone" />
          <input type="password" className="w-full border rounded-lg px-4 py-3" placeholder="Mot de passe" />
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold">
            S’inscrire
          </button>
        </form>
      </div>
    </div>
  );
}
