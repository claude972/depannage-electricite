import React, { useState } from 'react';

export default function CreateRequest() {
  const [step, setStep] = useState(1);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-md mx-auto bg-white rounded-2xl shadow p-6">
        <h2 className="text-2xl font-bold mb-6">Nouvelle demande</h2>
        
        {step === 1 && (
          <div className="space-y-4">
            <label className="block font-medium">Type de problème</label>
            <select className="w-full border rounded-lg p-3">
              <option>Panne de courant</option>
              <option>Disjoncteur</option>
              <option>Prise électrique</option>
              <option>Éclairage</option>
            </select>
            <button onClick={() => setStep(2)} className="w-full bg-blue-600 text-white py-3 rounded-lg">
              Continuer
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <label className="block font-medium">Description</label>
            <textarea className="w-full border rounded-lg p-3 h-32" placeholder="Décrivez le problème..." />
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="font-semibold">Fourchette estimée</p>
              <p className="text-2xl font-bold text-blue-600">150 – 250 €</p>
              <p className="text-sm text-gray-600">Aucune majoration 24/7</p>
            </div>
            <button className="w-full bg-blue-600 text-white py-3 rounded-lg">
              Confirmer la demande
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
