import React from 'react';

export default function Chat() {
  const messages = [
    { from: 'artisan', text: 'Bonjour, je suis en route. J’arrive dans 15 minutes.' },
    { from: 'client', text: 'Parfait, merci !' },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <div className="bg-white border-b p-4 font-semibold">Julien Moreau</div>
      
      <div className="flex-1 p-4 space-y-3 overflow-auto">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.from === 'client' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs px-4 py-2 rounded-2xl ${m.from === 'client' ? 'bg-blue-600 text-white' : 'bg-white'}`}>
              {m.text}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border-t p-3 flex gap-2">
        <input className="flex-1 border rounded-full px-4 py-2" placeholder="Écrire un message..." />
        <button className="bg-blue-600 text-white px-5 rounded-full">Envoyer</button>
      </div>
    </div>
  );
}
